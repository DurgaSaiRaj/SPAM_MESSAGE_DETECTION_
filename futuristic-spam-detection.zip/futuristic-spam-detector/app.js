/* ==========================================================================
   AEGISNET - CORE APPLICATION LOGIC
   ========================================================================== */

// --------------------------------------------------------------------------
// MOCK DATA & CONFIG
// --------------------------------------------------------------------------
// Example messages used only by the animated traffic demo on the left.
const STATIC_PRESETS = {
  spam: [
    "ALERT: Your cloud drive is 99% full. Secure your credentials at http://verify-cloud-login.info immediately.",
    "CONGRATS! You have been selected as the grand prize winner of $5,000 Cash! Call 1-800-FREE-CASH to claim now.",
    "URGENT // Security breach detected on terminal 82. Transfer your crypto assets to secure wallet: bc1qxy2kg...",
    "F R E E  V I A G R A! Order now at online-pharmacy-store-99.net and get 50% discount today only.",
    "Dear user, your debit card ending in 9812 has been suspended. Please confirm your details at http://suspend-card-resolutions.com.",
    "Double your Bitcoin holdings within 24 hours. Zero risk, fully verified. Click http://quantum-btc-booster.org."
  ],
  ham: [
    "Hey, are you still planning to meet up for coffee at 3 PM today? Let me know.",
    "The system updates have been successfully deployed to the production server. Latency looks stable.",
    "Can you send me the codebase report by tomorrow morning? Thanks.",
    "Let's review the code design during our sync tomorrow. Enjoy the rest of your evening!",
    "Hey mom, just wanted to check if you got the package I sent last week.",
    "Just checking in. The project is looking great and we are on track for the release."
  ]
};

// In-memory UI state: audio, quarantined rows, scan count, and the demo load timer.
let audioCtx = null;
let masterGain = null;
let audioEnabled = false;
let quarantinedItems = [];
let scanCounter = 0;
let systemLoadTimer = null;

// Cache HTML elements by ID so event handlers can update the page.
const selectors = {
  audioToggle: document.getElementById('audio-toggle'),
  audioLabel: document.getElementById('audio-status-label'),
  engineSelect: document.getElementById('engine-select'),
  engineStatus: document.getElementById('engine-status'),
  
  paramSensitivity: document.getElementById('param-sensitivity'),
  paramEntropy: document.getElementById('param-entropy'),
  paramLexicon: document.getElementById('param-lexicon'),
  
  valSensitivity: document.getElementById('val-sensitivity'),
  valEntropy: document.getElementById('val-entropy'),
  valLexicon: document.getElementById('val-lexicon'),
  
  statAccuracy: document.getElementById('stat-accuracy'),
  statFPs: document.getElementById('stat-fps'),
  statLoad: document.getElementById('stat-load'),
  statQuarantined: document.getElementById('stat-quarantined'),
  meterPercentVal: document.getElementById('meter-percent-val'),
  meterFillBar: document.getElementById('meter-fill-bar'),
  hdrLatency: document.getElementById('hdr-latency'),
  
  messageInput: document.getElementById('message-input'),
  inputErrorMessage: document.getElementById('input-error-message'),
  clearBtn: document.getElementById('clear-btn'),
  scanBtn: document.getElementById('scan-btn'),
  
  progressBar: document.getElementById('scanning-progress-bar'),
  progressFill: document.getElementById('progress-fill'),
  scanPhaseText: document.getElementById('scan-phase-text'),
  scanPercent: document.getElementById('scan-percent'),
  
  resultCard: document.getElementById('scan-result-card'),
  resThreatLevel: document.getElementById('res-threat-level'),
  resClassification: document.getElementById('res-classification'),
  resEntropy: document.getElementById('res-entropy'),
  resBadge: document.getElementById('result-status-badge'),
  
  vecUrgency: document.querySelector('#vec-urgency .box-value'),
  vecFinancial: document.querySelector('#vec-financial .box-value'),
  vecPhishing: document.querySelector('#vec-phishing .box-value'),
  vecEntropy: document.querySelector('#vec-entropy .box-value'),
  scanLogs: document.getElementById('scan-logs'),
  
  quarantineTableBody: document.getElementById('quarantine-table-body'),
  purgeVaultBtn: document.getElementById('purge-vault-btn'),
  
  inspectModal: document.getElementById('inspect-modal'),
  closeModalBtn: document.getElementById('close-modal-btn'),
  modalHash: document.getElementById('modal-hash'),
  modalWeight: document.getElementById('modal-weight'),
  modalRaw: document.getElementById('modal-raw'),
  modalHex: document.getElementById('modal-hex'),
  modalReleaseBtn: document.getElementById('modal-release-btn'),
  modalPurgeBtn: document.getElementById('modal-purge-btn'),
  
  packetStreamList: document.getElementById('packet-stream-list'),
  trafficCanvas: document.getElementById('traffic-canvas')
};

// ID of the quarantine item currently shown in the inspection popup.
let activeInspectId = null;

// --------------------------------------------------------------------------
// AUDIO SYNTH ENGINE (WEB AUDIO API)
// --------------------------------------------------------------------------
// Create the shared Web Audio nodes once, after the user enables audio.
function initAudio() {
  if (audioCtx) return;
  audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  masterGain = audioCtx.createGain();
  masterGain.connect(audioCtx.destination);
  masterGain.gain.setValueAtTime(0.12, audioCtx.currentTime); // keep sounds cyber-ambient, not piercing
}

// Play short synthesized UI sounds; each type selects a different sound pattern.
function playSound(type) {
  if (!audioEnabled) return;
  initAudio();
  if (audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  
  const now = audioCtx.currentTime;
  
  if (type === 'click') {
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(700, now);
    osc.frequency.exponentialRampToValueAtTime(100, now + 0.1);
    
    gain.gain.setValueAtTime(0.2, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.1);
    
    osc.connect(gain);
    gain.connect(masterGain);
    osc.start(now);
    osc.stop(now + 0.1);
    
  } else if (type === 'hover') {
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(1000, now);
    
    gain.gain.setValueAtTime(0.04, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.04);
    
    osc.connect(gain);
    gain.connect(masterGain);
    osc.start(now);
    osc.stop(now + 0.04);
    
  } else if (type === 'scan') {
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    const filter = audioCtx.createBiquadFilter();
    
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(120, now);
    osc.frequency.linearRampToValueAtTime(900, now + 1.2);
    osc.frequency.linearRampToValueAtTime(200, now + 1.5);
    
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(250, now);
    filter.frequency.linearRampToValueAtTime(1600, now + 1.2);
    
    gain.gain.setValueAtTime(0.1, now);
    gain.gain.linearRampToValueAtTime(0.12, now + 0.3);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 1.5);
    
    osc.connect(filter);
    filter.connect(gain);
    gain.connect(masterGain);
    osc.start(now);
    osc.stop(now + 1.5);
    
  } else if (type === 'success') {
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.type = 'sine';
    
    osc.frequency.setValueAtTime(650, now);
    osc.frequency.setValueAtTime(950, now + 0.08);
    
    gain.gain.setValueAtTime(0.2, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);
    
    osc.connect(gain);
    gain.connect(masterGain);
    osc.start(now);
    osc.stop(now + 0.25);
    
  } else if (type === 'alarm') {
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.type = 'square';
    
    osc.frequency.setValueAtTime(220, now);
    osc.frequency.linearRampToValueAtTime(380, now + 0.15);
    osc.frequency.linearRampToValueAtTime(220, now + 0.3);
    osc.frequency.linearRampToValueAtTime(380, now + 0.45);
    osc.frequency.linearRampToValueAtTime(220, now + 0.6);
    
    gain.gain.setValueAtTime(0.08, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.7);
    
    osc.connect(gain);
    gain.connect(masterGain);
    osc.start(now);
    osc.stop(now + 0.7);
    
  } else if (type === 'purge') {
    const bufferSize = audioCtx.sampleRate * 0.4;
    const buffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = Math.random() * 2 - 1;
    }
    
    const noise = audioCtx.createBufferSource();
    noise.buffer = buffer;
    
    const filter = audioCtx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(1200, now);
    filter.frequency.exponentialRampToValueAtTime(80, now + 0.4);
    
    const gain = audioCtx.createGain();
    gain.gain.setValueAtTime(0.25, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.4);
    
    noise.connect(filter);
    filter.connect(gain);
    gain.connect(masterGain);
    noise.start(now);
    noise.stop(now + 0.4);
  }
}

// Sound bindings for hover effects
// Add the same optional hover cue to a button or packet card.
function addHoverSounds(element) {
  element.addEventListener('mouseenter', () => playSound('hover'));
}

// --------------------------------------------------------------------------
// DYNAMIC NLP HEURISTIC CLASSIFIER
// --------------------------------------------------------------------------
// Estimate suspicious text formatting such as spaced letters, all-caps, or symbol-heavy text.
function calculateEntropy(text) {
  // Check obfuscation level (spaced letters, e.g. F R E E or leetspeak replacements)
  const clean = text.trim();
  if (clean.length === 0) return 0;
  
  // Rule 1: Multi-space letters
  // Match instances of single letters separated by exactly 1 space repeated multiple times
  const spacedMatch = clean.match(/(?:[a-zA-Z]\s){3,}[a-zA-Z]/g);
  let spacedScore = spacedMatch ? 0.8 : 0;
  
  // Rule 2: Upper Case ratio
  const uppercaseLetters = clean.replace(/[^A-Z]/g, "").length;
  const letters = clean.replace(/[^a-zA-Z]/g, "").length;
  let capsScore = 0;
  if (letters > 5) {
    const capsRatio = uppercaseLetters / letters;
    if (capsRatio > 0.6) capsScore = 0.6;
    else if (capsRatio > 0.4) capsScore = 0.3;
  }
  
  // Rule 3: Special characters density & leetspeak replacements (e.g., P@ypal, V1agra, Free!!!)
  const specialChars = clean.replace(/[a-zA-Z0-9\s,.]/g, "").length;
  const specialRatio = specialChars / clean.length;
  let symbolsScore = 0;
  if (specialRatio > 0.15) symbolsScore = 0.5;
  
  const leetMatches = (clean.match(/(?:[01]d|[pP]@[yY]|[vV]1[aA]|[fF]r33)/g) || []).length;
  const leetScore = leetMatches * 0.25;

  return Math.min(1.0, spacedScore + capsScore + symbolsScore + leetScore);
}

// Produce fallback risk-factor scores when the trained model API is unavailable.
function analyzeMessage(text, params) {
  const content = text.toLowerCase();

  // 1. Urgency Vector triggers
  const urgencyWords = ["urgent", "immediate", "act now", "limited time", "restricted", "suspended", "security breach", "alert", "action required", "decree", "final warning"];
  let urgencyMatches = 0;
  urgencyWords.forEach(word => {
    if (content.includes(word)) urgencyMatches++;
  });
  const urgencyWeight = Math.min(1.0, (urgencyMatches * 0.35) * params.lexiconBias);

  // 2. Financial Bait triggers
  const financialWords = ["win money", "cash prize", "cryptocurrency", "bitcoin", "lottery", "claim free", "$$$", "usd", "inheritance", "million dollars", "bank account", "verify debit card", "winner", "reward", "registration fees", "non-refundable", "fees", "stipend", "amount", "cash", "payout"];
  let financialMatches = 0;
  financialWords.forEach(word => {
    if (content.includes(word)) financialMatches++;
  });
  // Scan for numbers preceded by $ or followed by usd/dollars
  const hasMoneyValues = (content.match(/\$\d+/g) || []).length > 0;
  if (hasMoneyValues) financialMatches += 2;
  const hasIndianRupeeAmount = /₹\s?\d+|rs\.?\s?\d+|inr\s?\d+/.test(content);
  if (hasIndianRupeeAmount) financialMatches += 2;
  const financialWeight = Math.min(1.0, (financialMatches * 0.25) * params.lexiconBias);

  // 3. Mass-mailing / bulk outreach spam indicators
  const bulkMailSignals = [
    "dear sir", "dear madam", "respected sir", "respected madam", "kindly disseminate",
    "all states", "all universities", "all colleges", "official channels", "faculty, students",
    "vice chancellor", "registrar", "head of dept", "dean", "principal", "all central universities",
    "subject:", "regards,", "to,", "request to upload", "upload this announcement",
    "registration start date", "last date of reg", "batch - 1", "batch - 2", "contact@",
    "mobile no", "phone:", "website link:"
  ];
  let bulkMailMatches = 0;
  bulkMailSignals.forEach(signal => {
    if (content.includes(signal)) bulkMailMatches++;
  });
  const hasContactInfo = /(contact@|email:|phone:|mobile no|mobile number|call|whatsapp)/i.test(text);
  const bulkMailWeight = Math.min(1.0, (bulkMailMatches * 0.18) + (hasContactInfo ? 0.25 : 0));

  // 4. Phishing / Link Harvester triggers
  // Check for HTTP/HTTPS links
  const urls = text.match(/https?:\/\/[^\s]+/gi) || [];
  let phishingWeight = 0;
  if (urls.length > 0) {
    phishingWeight += 0.5;
    // Check for lookalikes or suspicious domains
    const suspiciousDomains = ["secure", "verify", "login", "bank", "portal", "update", "signin", "support-cloud", "resolution", "prize", "jackpot", "claim", "verify", "suspend"];
    urls.forEach(url => {
      suspiciousDomains.forEach(domain => {
        if (url.toLowerCase().includes(domain)) phishingWeight += 0.2;
      });
      // Shorteners
      if (url.toLowerCase().includes("bit.ly") || url.toLowerCase().includes("tinyurl.com") || url.toLowerCase().includes("t.co")) {
        phishingWeight += 0.25;
      }
      // Many scam messages use a website plus a contact mechanism or payment ask. Boost if multiple links are present or if there are any payment cues nearby.
      if (content.includes("website") || content.includes("link") || content.includes("contact@")) {
        phishingWeight += 0.1;
      }
    });
  }
  if (content.includes("email:") || content.includes("phone:") || content.includes("mobile no")) {
    phishingWeight += 0.15;
  }
  phishingWeight = Math.min(1.0, phishingWeight);

  // 5. Syntactic Obfuscation / Entropy
  const rawEntropy = calculateEntropy(text);
  const entropyWeight = Math.min(1.0, rawEntropy * (1.2 - params.entropyTolerance));

  // Compute Aggregate Score
  const aggregateScore = (urgencyWeight * 0.2) + (financialWeight * 0.25) + (bulkMailWeight * 0.25) + (phishingWeight * 0.2) + (entropyWeight * 0.1);
  
  // Decide Spam Flag based on Sensitivity threshold
  const isSpam = aggregateScore >= params.threatSensitivity;

  return {
    isSpam,
    score: aggregateScore,
    urgencyWeight,
    financialWeight,
    phishingWeight,
    entropyWeight,
    bulkMailWeight,
    details: {
      urls,
      urgencyMatches,
      financialMatches,
      rawEntropy,
      bulkMailMatches,
      hasContactInfo
    }
  };
}

// --------------------------------------------------------------------------
// MAIN INTERFACES & TUNING SYSTEM
// --------------------------------------------------------------------------
// Read the current slider and engine values from the page.
function getParameters() {
  return {
    threatSensitivity: parseFloat(selectors.paramSensitivity.value),
    entropyTolerance: parseFloat(selectors.paramEntropy.value),
    lexiconBias: parseFloat(selectors.paramLexicon.value),
    engine: selectors.engineSelect.value
  };
}

// Refresh slider labels and dashboard indicators when tuning controls change.
// The accuracy/load/latency values below are display simulations, not measured model metrics.
function updateParamsUI() {
  const params = getParameters();
  selectors.valSensitivity.innerText = params.threatSensitivity.toFixed(2);
  selectors.valEntropy.innerText = params.entropyTolerance.toFixed(2);
  selectors.valLexicon.innerText = params.lexiconBias.toFixed(2);
  
  // Dynamic stats changes to simulate how system handles models
  let baseAccuracy = 95.2;
  let baseFPs = 0.5;
  let baseLoad = 8.5;
  let baseLatency = 10;

  if (params.engine === 'ares') {
    selectors.engineStatus.innerText = 'A.R.E.S. NEURAL NET v6.0';
    baseAccuracy = 98.8;
    baseFPs = 0.15;
    baseLoad = 32.0;
    baseLatency = 42;
  } else if (params.engine === 'kronos') {
    selectors.engineStatus.innerText = 'KRONOS HEURISTICS v1.1';
    baseAccuracy = 91.5;
    baseFPs = 1.25;
    baseLoad = 5.0;
    baseLatency = 4;
  } else {
    selectors.engineStatus.innerText = 'HYPERION MATRIX v4.2';
    baseAccuracy = 96.4;
    baseFPs = 0.42;
    baseLoad = 14.2;
    baseLatency = 16;
  }

  // Adjust stats according to parameters
  // Higher sensitivity captures more spam but slightly increases False Positives
  const fpAdjustment = (params.threatSensitivity < 0.4) ? (0.6 / params.threatSensitivity) : -(params.threatSensitivity * 0.2);
  const finalFPs = Math.max(0.01, baseFPs + fpAdjustment);
  
  // Higher Lexicon bias/Entropy tolerance increases load due to scanning depth
  const finalLoad = Math.min(100.0, baseLoad + (params.lexiconBias * 10) + ((1 - params.entropyTolerance) * 12));
  
  // Accuracy is optimized at balanced settings
  const balancePenalty = Math.abs(params.threatSensitivity - 0.5) * 4;
  const finalAccuracy = Math.min(99.9, baseAccuracy - balancePenalty);

  // Update UI Elements
  selectors.statAccuracy.innerText = finalAccuracy.toFixed(2) + '%';
  selectors.statFPs.innerText = finalFPs.toFixed(2) + '%';
  selectors.statLoad.innerText = finalLoad.toFixed(1) + '%';
  selectors.hdrLatency.innerText = baseLatency + 'ms';

  // Calculate efficiency fill bar
  const efficiency = Math.round(100 - (baseLatency * 0.8 + (finalLoad * 0.4)));
  const finalEfficiency = Math.max(10, Math.min(99, efficiency));
  selectors.meterPercentVal.innerText = finalEfficiency + '%';
  selectors.meterFillBar.style.width = finalEfficiency + '%';
}

// Generate secure token/hash
// Create a short repeatable display ID for a message; this is not a cryptographic hash.
function generateHash(text) {
  let hash = 0;
  for (let i = 0; i < text.length; i++) {
    hash = (hash << 5) - hash + text.charCodeAt(i);
    hash |= 0;
  }
  return 'ANX-' + Math.abs(hash).toString(16).toUpperCase().substring(0, 10);
}

// Ask the trained Python model for a spam probability and keep heuristic scores for the risk-factor display.
async function getModelPrediction(text, params) {
  const fallbackAnalysis = analyzeMessage(text, params);
  // Higher sensitivity lowers the model cutoff, making spam detection more aggressive.
  const threshold = Math.min(0.59, Math.max(0.15, 0.65 - params.threatSensitivity * 0.6));

  try {
    const response = await fetch('/api/predict', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ text, threshold })
    });

    if (!response.ok) {
      throw new Error(`Model service returned HTTP ${response.status}`);
    }

    const prediction = await response.json();
    if (typeof prediction.is_spam === 'boolean') {
      appendScanLog(`[AI] Trained-model verdict received (${Math.round(prediction.score * 100)}% spam probability).`);
      return {
        ...fallbackAnalysis,
        isSpam: prediction.is_spam,
        score: Number(prediction.score ?? fallbackAnalysis.score),
        details: {
          ...fallbackAnalysis.details,
          modelLabel: prediction.label,
          modelConfidence: Number(prediction.confidence ?? 0)
        }
      };
    }
    throw new Error('Model service returned an invalid prediction');
  } catch (error) {
    console.error('Trained spam model request failed:', error);
    appendScanLog(`[WARN] Trained model unavailable (${error.message}). Falling back to heuristic analysis.`);
  }

  return fallbackAnalysis;
}

// --------------------------------------------------------------------------
// SCANNING EXECUTION & PIPELINE
// --------------------------------------------------------------------------
// Validate the input, animate scan progress, then request the model verdict.
function startMessageScan() {
  const text = selectors.messageInput.value.trim();
  if (text.length === 0) {
    selectors.inputErrorMessage.classList.remove('hidden');
    selectors.resultCard.classList.add('hidden');
    selectors.progressBar.classList.add('hidden');
    return;
  }
  
  selectors.inputErrorMessage.classList.add('hidden');
  playSound('click');
  playSound('scan');
  
  // Lock interface during sweep
  selectors.scanBtn.disabled = true;
  selectors.clearBtn.disabled = true;
  selectors.progressBar.classList.remove('hidden');
  selectors.resultCard.classList.add('hidden');
  selectors.scanLogs.innerHTML = '';
  
  let progress = 0;
  selectors.progressFill.style.width = '0%';
  
  const phases = [
    { threshold: 20, text: "INITIATING TRANS-NEURAL SCAN..." },
    { threshold: 45, text: "DECRYPTING UTF INTERCEPT LAYER..." },
    { threshold: 70, text: "EVALUATING SEMANTIC THREAT VECTORS..." },
    { threshold: 90, text: "MEASURING SYNTACTIC ENTROPY WEIGHTS..." },
    { threshold: 100, text: "COMPUTING QUARANTINE MATRIX..." }
  ];

  const logLines = [
    "[INFO] Initializing quantum decryptor memory buffer.",
    `[INFO] Packet length: ${text.length} chars. Hashing bytes...`,
    `[SYSTEM] Security Hash established: ${generateHash(text)}`,
    "[PARSING] Stripping transport headers. Evaluating token vectors.",
    "[VECTOR] Matching tokens against local lexical threat grids.",
    "[HEURISTICS] Calculating character distance distribution.",
    "[ANALYSIS] Running classification algorithms..."
  ];

  let logIndex = 0;
  
  const scanInterval = setInterval(() => {
    progress += Math.floor(Math.random() * 5) + 3;
    if (progress > 100) progress = 100;
    
    selectors.progressFill.style.width = progress + '%';
    selectors.scanPercent.innerText = progress + '%';
    
    // Phase update
    const currentPhase = phases.find(p => progress <= p.threshold) || phases[phases.length - 1];
    selectors.scanPhaseText.innerText = currentPhase.text;

    // Log line generator
    if (progress > (logIndex + 1) * 14 && logIndex < logLines.length) {
      appendScanLog(logLines[logIndex]);
      logIndex++;
    }

    if (progress >= 100) {
      clearInterval(scanInterval);
      setTimeout(async () => {
        await finalizeScanResult(text);
      }, 300);
    }
  }, 50);
}

// Hide the empty-input warning as soon as the user edits the message.
function clearInputError() {
  selectors.inputErrorMessage.classList.add('hidden');
}

// Add one status line to the scan log and color important system/warning messages.
function appendScanLog(message) {
  const line = document.createElement('div');
  line.innerText = `>> ${message}`;
  
  // Highlight warnings
  if (message.includes('[SYSTEM]') || message.includes('Hash')) {
    line.style.color = 'var(--neon-cyan)';
  } else if (message.includes('[WARN]')) {
    line.style.color = 'var(--neon-pink)';
  }
  
  selectors.scanLogs.appendChild(line);
  selectors.scanLogs.scrollTop = selectors.scanLogs.scrollHeight;
}

// Apply a model verdict to the result card and quarantine spam automatically.
async function finalizeScanResult(text) {
  selectors.scanBtn.disabled = false;
  selectors.clearBtn.disabled = false;
  selectors.progressBar.classList.add('hidden');
  
  const params = getParameters();
  const analysis = await getModelPrediction(text, params);

  // Sound cues based on spam/ham
  if (analysis.isSpam) {
    playSound('alarm');
    selectors.resultCard.classList.add('spam-detected');
    selectors.resBadge.innerText = "QUARANTINED";
    selectors.resClassification.innerText = "SPAM THREAT (COMPROMISED)";
    selectors.resClassification.className = "value pink-text";
    
    // Add warning logs
    appendScanLog("[WARN] HIGH PROBABILITY PHISHING/SPAM DETECTED.");
    appendScanLog("[ACTION] ROTATING PAYLOAD KEY. ROUTING TO QUARANTINE VAULT.");
    
    // Quarantine automatically
    quarantinePayload(text, analysis);
  } else {
    playSound('success');
    selectors.resultCard.classList.remove('spam-detected');
    selectors.resBadge.innerText = "SECURED";
    selectors.resClassification.innerText = "SAFE (VERIFIED TRANSMISSION)";
    selectors.resClassification.className = "value green-text";
    
    appendScanLog("[INFO] Transmission verification succeeded.");
    appendScanLog("[SYSTEM] Payload cleared. Safe routing allowed.");
  }

  // Load numbers into results UI
  selectors.resThreatLevel.innerText = (analysis.score * 100).toFixed(1) + '%';
  selectors.resThreatLevel.className = `value ${analysis.isSpam ? 'pink-text' : 'green-text'}`;
  
  // Entropy text label
  if (analysis.entropyWeight > 0.7) {
    selectors.resEntropy.innerText = "Extreme (High obfuscation)";
    selectors.resEntropy.className = "value pink-text";
  } else if (analysis.entropyWeight > 0.4) {
    selectors.resEntropy.innerText = "Moderate";
    selectors.resEntropy.className = "value amber-text";
  } else {
    selectors.resEntropy.innerText = "Low";
    selectors.resEntropy.className = "value green-text";
  }

  // Vector bars
  selectors.vecUrgency.innerText = Math.round(analysis.urgencyWeight * 100) + '%';
  selectors.vecUrgency.parentElement.className = `vector-indicator-box ${analysis.urgencyWeight > 0.5 ? 'flagged pink-text' : ''}`;
  
  selectors.vecFinancial.innerText = Math.round(analysis.financialWeight * 100) + '%';
  selectors.vecFinancial.parentElement.className = `vector-indicator-box ${analysis.financialWeight > 0.5 ? 'flagged pink-text' : ''}`;
  
  selectors.vecPhishing.innerText = Math.round(analysis.phishingWeight * 100) + '%';
  selectors.vecPhishing.parentElement.className = `vector-indicator-box ${analysis.phishingWeight > 0.5 ? 'flagged pink-text' : ''}`;
  
  selectors.vecEntropy.innerText = Math.round(analysis.entropyWeight * 100) + '%';
  selectors.vecEntropy.parentElement.className = `vector-indicator-box ${analysis.entropyWeight > 0.5 ? 'flagged pink-text' : ''}`;

  selectors.resultCard.classList.remove('hidden');
}

// --------------------------------------------------------------------------
// QUARANTINE VAULT DATABASE CONTROLLERS
// --------------------------------------------------------------------------
// Store a spam verdict in the in-memory quarantine list and refresh its table.
function quarantinePayload(text, analysis) {
  const timestamp = new Date();
  const id = generateHash(text);
  
  // Determine threat category
  let threatClass = "SCAM AD";
  if (analysis.phishingWeight > 0.4) threatClass = "PHISHING";
  else if (analysis.urgencyWeight > 0.7) threatClass = "MALICIOUS ALERT";
  else if (analysis.entropyWeight > 0.7) threatClass = "OBFUSCATED CODE";

  const item = {
    id,
    timestamp: timestamp.toLocaleTimeString() + ' ' + timestamp.toLocaleDateString(),
    threatClass,
    score: (analysis.score * 100).toFixed(0) + '%',
    rawText: text,
    analysis
  };

  quarantinedItems.unshift(item);
  renderQuarantineTable();
  selectors.statQuarantined.innerText = quarantinedItems.length;
}

// Rebuild the quarantine table from the current in-memory list and attach row actions.
function renderQuarantineTable() {
  selectors.quarantineTableBody.innerHTML = '';
  
  if (quarantinedItems.length === 0) {
    selectors.quarantineTableBody.innerHTML = `
      <tr class="empty-row">
        <td colspan="6">Vault offline or empty. No digital anomalies isolated.</td>
      </tr>
    `;
    return;
  }

  quarantinedItems.forEach(item => {
    const tr = document.createElement('tr');
    tr.className = "spam-row";
    
    tr.innerHTML = `
      <td>${item.id}</td>
      <td class="text-muted">${item.timestamp}</td>
      <td class="pink-text font-bold">${item.threatClass}</td>
      <td class="amber-text">${item.score}</td>
      <td class="text-muted" style="max-width: 300px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
        ${item.rawText}
      </td>
      <td style="text-align: center;">
        <button class="btn-table-action inspect" data-id="${item.id}">INSPECT</button>
        <button class="btn-table-action release" data-id="${item.id}">RELEASE</button>
        <button class="btn-table-action purge" data-id="${item.id}">PURGE</button>
      </td>
    `;
    
    // Bind buttons
    tr.querySelector('.inspect').addEventListener('click', () => openInspectModal(item.id));
    tr.querySelector('.release').addEventListener('click', () => releaseItem(item.id));
    tr.querySelector('.purge').addEventListener('click', () => purgeItem(item.id));
    
    // Add hover clicks to buttons
    addHoverSounds(tr.querySelector('.inspect'));
    addHoverSounds(tr.querySelector('.release'));
    addHoverSounds(tr.querySelector('.purge'));

    selectors.quarantineTableBody.appendChild(tr);
  });
}

// Remove one quarantined item by its generated ID.
function purgeItem(id) {
  playSound('purge');
  quarantinedItems = quarantinedItems.filter(item => item.id !== id);
  renderQuarantineTable();
  selectors.statQuarantined.innerText = quarantinedItems.length;
  
  if (activeInspectId === id) {
    closeInspectModal();
  }
}

// Put a quarantined message back in the input, display its analysis, and remove its stored row.
function releaseItem(id) {
  playSound('success');
  const item = quarantinedItems.find(item => item.id === id);
  if (item) {
    // Whitelist payload: load back to scanner as secure
    selectors.messageInput.value = item.rawText;
    finalizeScanResult(item.rawText); // Force re-scan to show it whitelisted
    
    quarantinedItems = quarantinedItems.filter(item => item.id !== id);
    renderQuarantineTable();
    selectors.statQuarantined.innerText = quarantinedItems.length;
  }
  closeInspectModal();
}

// Ask for confirmation, then empty the entire quarantine list.
function purgeAllVault() {
  if (quarantinedItems.length === 0) return;
  if (confirm("WARNING: Confirm atomic purge of all isolated digital anomalies in vault?")) {
    playSound('purge');
    quarantinedItems = [];
    renderQuarantineTable();
    selectors.statQuarantined.innerText = '0';
  }
}

// Hex Dump helper
// Format message characters as hexadecimal bytes for display in the inspection popup.
function generateHexDump(str) {
  let result = '';
  for (let i = 0; i < str.length; i += 8) {
    const chunk = str.slice(i, i + 8);
    let hex = '';
    let ascii = '';
    for (let j = 0; j < 8; j++) {
      if (j < chunk.length) {
        const code = chunk.charCodeAt(j);
        hex += code.toString(16).padStart(2, '0').toUpperCase() + ' ';
        ascii += (code >= 32 && code <= 126) ? chunk[j] : '.';
      } else {
        hex += '   ';
        ascii += ' ';
      }
    }
    const offset = i.toString(16).padStart(4, '0').toUpperCase();
    result += `${offset}  ${hex} | ${ascii}\n`;
  }
  return result;
}

// Inspection Modal Controllers
// Populate and open the popup for the selected quarantined message.
function openInspectModal(id) {
  playSound('click');
  activeInspectId = id;
  const item = quarantinedItems.find(i => i.id === id);
  if (!item) return;

  selectors.modalHash.innerText = item.id;
  selectors.modalWeight.innerText = item.score + ` (Classification: ${item.threatClass})`;
  selectors.modalRaw.innerText = item.rawText;
  selectors.modalHex.innerText = generateHexDump(item.rawText);
  
  selectors.inspectModal.classList.remove('hidden');
}

// Hide the inspection popup and clear the selected item ID.
function closeInspectModal() {
  playSound('click');
  selectors.inspectModal.classList.add('hidden');
  activeInspectId = null;
}

// --------------------------------------------------------------------------
// CANVAS TRAFFIC NODE SYSTEM (SIMULATION & ANIMATION)
// --------------------------------------------------------------------------
// Get the canvas drawing context and arrays that hold simulated nodes and moving packets.
const canvas = selectors.trafficCanvas;
const ctx = canvas.getContext('2d');

let canvasNodes = [];
let canvasPackets = [];

// Setup Canvas Size
// Size the drawing surface and position the two demo gateways, filter, and destinations.
function initCanvas() {
  const container = canvas.parentElement;
  canvas.width = container.clientWidth;
  canvas.height = container.clientHeight;
  
  // Define layout node coordinates relative to width/height
  const w = canvas.width;
  const h = canvas.height;
  
  canvasNodes = [
    { id: 'src1', name: 'GATEWAY_A', x: w * 0.15, y: h * 0.25, color: 'var(--neon-cyan)', pulse: 0 },
    { id: 'src2', name: 'GATEWAY_B', x: w * 0.15, y: h * 0.75, color: 'var(--neon-cyan)', pulse: 0 },
    { id: 'filter', name: 'NEURAL_FILTER', x: w * 0.5, y: h * 0.5, color: '#f3a123', pulse: 0 },
    { id: 'safe_sink', name: 'SECURE_SINK', x: w * 0.85, y: h * 0.25, color: 'var(--neon-green)', pulse: 0 },
    { id: 'quar_sink', name: 'QUARANTINE', x: w * 0.85, y: h * 0.75, color: 'var(--neon-pink)', pulse: 0 }
  ];
}

// Represents one animated demo packet as it travels from a gateway through the filter to a sink.
class Packet {
  constructor(payload, isSpam, startNode, filterNode, endNode) {
    this.payload = payload;
    this.isSpam = isSpam;
    this.startNode = startNode;
    this.filterNode = filterNode;
    this.endNode = endNode;
    
    this.x = startNode.x;
    this.y = startNode.y;
    this.progress = 0; // 0 to 1
    this.stage = 1; // 1: src->filter, 2: filter->sink
    this.speed = 0.007 + Math.random() * 0.005;
    
    this.color = 'var(--neon-cyan)';
    this.size = 4;
  }

  update() {
    this.progress += this.speed;
    
    if (this.stage === 1) {
      // Calculate linear interpolate position
      this.x = this.startNode.x + (this.filterNode.x - this.startNode.x) * this.progress;
      this.y = this.startNode.y + (this.filterNode.y - this.startNode.y) * this.progress;
      
      if (this.progress >= 1.0) {
        this.stage = 2;
        this.progress = 0;
        this.filterNode.pulse = 1.0; // trigger gate trigger blink
        
        // Highlight scanner engine briefly
        if (this.isSpam) {
          this.color = 'var(--neon-pink)';
          this.size = 5;
        } else {
          this.color = 'var(--neon-green)';
        }
      }
    } else if (this.stage === 2) {
      this.x = this.filterNode.x + (this.endNode.x - this.filterNode.x) * this.progress;
      this.y = this.filterNode.y + (this.endNode.y - this.filterNode.y) * this.progress;
      
      if (this.progress >= 1.0) {
        this.endNode.pulse = 1.0;
        return true; // remove packet
      }
    }
    return false;
  }

  draw() {
    ctx.beginPath();
    ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
    ctx.fillStyle = this.color;
    ctx.shadowBlur = 8;
    ctx.shadowColor = this.color;
    ctx.fill();
    ctx.shadowBlur = 0; // reset
  }
}

// Spawn canvas animations
// Pick a preset example at random and animate it along the demo's safe or spam route.
function spawnSimulatedPacket() {
  if (canvasNodes.length === 0) return;
  
  const isSpam = Math.random() > 0.5;
  const list = isSpam ? STATIC_PRESETS.spam : STATIC_PRESETS.ham;
  const text = list[Math.floor(Math.random() * list.length)];
  
  const src = canvasNodes[Math.floor(Math.random() * 2)]; // select src1 or src2
  const filter = canvasNodes[2];
  const sink = isSpam ? canvasNodes[4] : canvasNodes[3];
  
  const p = new Packet(text, isSpam, src, filter, sink);
  canvasPackets.push(p);

  // Push meta details in dynamic left list
  addPacketToFeed(text, isSpam);
}

// Manage dynamic packet list feed on Left Column
// Add a clickable sample to the feed; selecting it copies the text into the scanner input.
function addPacketToFeed(text, isSpam) {
  const packetNode = document.createElement('div');
  packetNode.className = `packet-node ${isSpam ? 'spam-threat' : ''}`;
  
  const time = new Date().toLocaleTimeString().substring(0, 8);
  const hash = generateHash(text).substring(0, 8);

  packetNode.innerHTML = `
    <div class="packet-meta">
      <span class="cyan-text font-bold">${hash}</span>
      <span>${time}</span>
    </div>
    <div class="packet-snippet">${text}</div>
  `;
  
  packetNode.addEventListener('click', () => {
    playSound('click');
    selectors.messageInput.value = text;
    // Visually scroll/flash scanner input
    selectors.messageInput.focus();
    selectors.messageInput.classList.add('flash-cyan');
    setTimeout(() => selectors.messageInput.classList.remove('flash-cyan'), 500);
  });
  
  addHoverSounds(packetNode);

  selectors.packetStreamList.insertBefore(packetNode, selectors.packetStreamList.firstChild);

  // Limit items list count
  if (selectors.packetStreamList.children.length > 8) {
    selectors.packetStreamList.removeChild(selectors.packetStreamList.lastChild);
  }
}

// Canvas Render Loop
// Redraw links, nodes, and moving demo packets once per browser animation frame.
function drawCanvas() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  
  // 1. Draw connection cables / links
  ctx.strokeStyle = 'rgba(0, 242, 254, 0.08)';
  ctx.lineWidth = 2;
  
  // Src 1 -> Filter
  ctx.beginPath();
  ctx.moveTo(canvasNodes[0].x, canvasNodes[0].y);
  ctx.lineTo(canvasNodes[2].x, canvasNodes[2].y);
  ctx.stroke();

  // Src 2 -> Filter
  ctx.beginPath();
  ctx.moveTo(canvasNodes[1].x, canvasNodes[1].y);
  ctx.lineTo(canvasNodes[2].x, canvasNodes[2].y);
  ctx.stroke();

  // Filter -> Sink 1 (Safe)
  ctx.beginPath();
  ctx.moveTo(canvasNodes[2].x, canvasNodes[2].y);
  ctx.lineTo(canvasNodes[3].x, canvasNodes[3].y);
  ctx.stroke();

  // Filter -> Sink 2 (Quarantine)
  ctx.beginPath();
  ctx.moveTo(canvasNodes[2].x, canvasNodes[2].y);
  ctx.lineTo(canvasNodes[4].x, canvasNodes[4].y);
  ctx.stroke();

  // 2. Draw nodes
  canvasNodes.forEach(node => {
    // Pulse animation
    if (node.pulse > 0) {
      node.pulse -= 0.05;
    }
    
    // Draw outer glow rings
    ctx.beginPath();
    ctx.arc(node.x, node.y, 14 + (node.pulse * 10), 0, Math.PI * 2);
    ctx.strokeStyle = node.color;
    ctx.lineWidth = 1;
    ctx.shadowBlur = 4;
    ctx.shadowColor = node.color;
    ctx.stroke();
    
    // Draw core circle
    ctx.beginPath();
    ctx.arc(node.x, node.y, 6, 0, Math.PI * 2);
    ctx.fillStyle = node.color;
    ctx.fill();
    ctx.shadowBlur = 0; // reset
    
    // Labels
    ctx.fillStyle = 'var(--text-muted)';
    ctx.font = '8px "Share Tech Mono"';
    ctx.textAlign = 'center';
    ctx.fillText(node.name, node.x, node.y - 20);
  });

  // 3. Update & Draw Packets
  canvasPackets = canvasPackets.filter(packet => {
    const finished = packet.update();
    packet.draw();
    return !finished;
  });

  requestAnimationFrame(drawCanvas);
}

// --------------------------------------------------------------------------
// SYSTEM INTERACTION HANDLERS & REGULAR TICKERS
// --------------------------------------------------------------------------
// Connect buttons, sliders, and modal controls to their corresponding app actions.
function setupEvents() {
  // Load and Tuning events
  selectors.paramSensitivity.addEventListener('input', updateParamsUI);
  selectors.paramEntropy.addEventListener('input', updateParamsUI);
  selectors.paramLexicon.addEventListener('input', updateParamsUI);
  selectors.engineSelect.addEventListener('change', updateParamsUI);

  // Buffer scanner triggers
  selectors.scanBtn.addEventListener('click', startMessageScan);
  selectors.messageInput.addEventListener('input', clearInputError);
  selectors.clearBtn.addEventListener('click', () => {
    playSound('click');
    selectors.messageInput.value = '';
    selectors.resultCard.classList.add('hidden');
    clearInputError();
  });

  // Audio Toggle
  selectors.audioToggle.addEventListener('click', () => {
    audioEnabled = !audioEnabled;
    if (audioEnabled) {
      initAudio();
      selectors.audioToggle.classList.add('cyan-text');
      selectors.audioLabel.innerText = "ON";
      playSound('success');
    } else {
      selectors.audioToggle.classList.remove('cyan-text');
      selectors.audioLabel.innerText = "OFF";
    }
  });

  // Quarantine Vault events
  selectors.purgeVaultBtn.addEventListener('click', purgeAllVault);

  // Modal events
  selectors.closeModalBtn.addEventListener('click', closeInspectModal);
  selectors.modalPurgeBtn.addEventListener('click', () => {
    if (activeInspectId) {
      purgeItem(activeInspectId);
    }
  });
  selectors.modalReleaseBtn.addEventListener('click', () => {
    if (activeInspectId) {
      releaseItem(activeInspectId);
    }
  });

  // Sound cues for interface controls
  addHoverSounds(selectors.scanBtn);
  addHoverSounds(selectors.clearBtn);
  addHoverSounds(selectors.audioToggle);
  addHoverSounds(selectors.purgeVaultBtn);
  addHoverSounds(selectors.closeModalBtn);
  addHoverSounds(selectors.modalPurgeBtn);
  addHoverSounds(selectors.modalReleaseBtn);

  // Handle window resizing
  window.addEventListener('resize', initCanvas);
}

// Simulate system load variations
// Animate the displayed load number; it is a visual simulation, not measured CPU usage.
function startLoadSimulation() {
  systemLoadTimer = setInterval(() => {
    const currentVal = parseFloat(selectors.statLoad.innerText);
    const fluctuation = (Math.random() * 4 - 2); // fluctuation +/- 2%
    let newVal = currentVal + fluctuation;
    newVal = Math.max(3.0, Math.min(99.0, newVal));
    selectors.statLoad.innerText = newVal.toFixed(1) + '%';
  }, 3000);
}

// --------------------------------------------------------------------------
// INITIALIZER
// --------------------------------------------------------------------------
// Wire up the dashboard, draw the demo, insert example packets, and start UI timers.
function init() {
  setupEvents();
  initCanvas();
  
  // Run canvas rendering
  requestAnimationFrame(drawCanvas);
  
  // Pre-load parameters calculations
  updateParamsUI();
  
  // Initialize simulated incoming streams
  setInterval(spawnSimulatedPacket, 4000);
  // Spawn initial set
  for (let i = 0; i < 4; i++) {
    spawnSimulatedPacket();
  }

  // Prepopulate Quarantine Vault
  const initialQuarantineList = [
    "WARNING!! Your online billing portal password has expired. Click link immediately: http://login-billing-alert.net/auth to verify status.",
    "WINNER NOTICE: Your ticket ID code 8912-A has won a payout reward value of 0.82 BTC ($48,000 USD). Claim payload at bc1qq0..."
  ];
  initialQuarantineList.forEach(text => {
    const analysis = analyzeMessage(text, getParameters());
    quarantinePayload(text, analysis);
  });

  startLoadSimulation();
  
  console.log("AEGISNET terminal system online.");
}

window.addEventListener('DOMContentLoaded', init);
