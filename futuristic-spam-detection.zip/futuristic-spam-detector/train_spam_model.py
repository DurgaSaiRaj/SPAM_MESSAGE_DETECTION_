from __future__ import annotations

import json
from pathlib import Path

import joblib
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import accuracy_score, classification_report
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import FeatureUnion, Pipeline

DATASET_PATH = Path(__file__).resolve().parent / "dataset" / "spam.csv"
MODEL_PATH = Path(__file__).resolve().parent / "models" / "spam_model.joblib"
METADATA_PATH = Path(__file__).resolve().parent / "models" / "spam_model_metadata.json"
SPAM_THRESHOLD = 0.35


def load_dataset(path: Path) -> pd.DataFrame:
    df = pd.read_csv(
        path,
        encoding="latin-1",
        usecols=[0, 1],
        header=0,
        names=["label", "message"],
        engine="python",
        on_bad_lines="skip",
    )
    df = df.dropna(subset=["label", "message"]).copy()
    df["label"] = df["label"].astype(str).str.strip().str.lower()
    df["message"] = df["message"].astype(str).str.strip()
    df = df[df["label"].isin(["ham", "spam"])].copy()
    return df


def build_model() -> Pipeline:
    return Pipeline(
        steps=[
            (
                "features",
                FeatureUnion(
                    [
                        (
                            "word",
                            TfidfVectorizer(
                                lowercase=True,
                                ngram_range=(1, 3),
                                min_df=1,
                                sublinear_tf=True,
                            ),
                        ),
                        (
                            "character",
                            TfidfVectorizer(
                                analyzer="char_wb",
                                ngram_range=(2, 5),
                                min_df=2,
                                max_features=150_000,
                                sublinear_tf=True,
                            ),
                        ),
                    ]
                ),
            ),
            (
                "clf",
                LogisticRegression(
                    max_iter=1500,
                    class_weight="balanced",
                    C=2.0,
                ),
            ),
        ]
    )


def main() -> None:
    df = load_dataset(DATASET_PATH)

    X = df["message"].astype(str)
    y = df["label"].map({"ham": 0, "spam": 1})

    X_train, X_test, y_train, y_test = train_test_split(
        X,
        y,
        test_size=0.2,
        random_state=42,
        stratify=y,
    )

    evaluation_model = build_model()
    evaluation_model.fit(X_train, y_train)

    spam_probabilities = evaluation_model.predict_proba(X_test)[:, 1]
    preds = spam_probabilities >= SPAM_THRESHOLD
    acc = accuracy_score(y_test, preds)
    report = classification_report(y_test, preds, target_names=["ham", "spam"], output_dict=True)

    model = build_model()
    model.fit(X, y)

    MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(model, MODEL_PATH)

    metadata = {
        "dataset": str(DATASET_PATH),
        "training_rows": int(len(df)),
        "evaluation_rows": int(len(y_test)),
        "spam_threshold": SPAM_THRESHOLD,
        "accuracy": float(acc),
        "report": report,
        "label_map": {"ham": 0, "spam": 1},
    }
    with METADATA_PATH.open("w", encoding="utf-8") as f:
        json.dump(metadata, f, indent=2)

    print(f"Model saved to: {MODEL_PATH}")
    print(f"Training rows: {len(df)}")
    print(f"Held-out accuracy at threshold {SPAM_THRESHOLD:.2f}: {acc:.4f}")
    print(classification_report(y_test, preds, target_names=["ham", "spam"]))

    sample = [
        "URGENT! You have won a free prize. Click now to claim your reward.",
        "Hey, can we meet for coffee tomorrow at 3 PM?",
    ]
    print("Sample predictions:")
    for text in sample:
        probability = float(model.predict_proba([text])[0][1])
        label = "spam" if probability >= SPAM_THRESHOLD else "ham"
        print(f"{text} -> {label} ({probability:.1%} spam probability)")


if __name__ == "__main__":
    main()
