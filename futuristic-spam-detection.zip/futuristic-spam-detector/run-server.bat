@echo off
title AegisNet Server Panel
echo ========================================================
echo   AEGISNET // NEURAL THREAT FILTRATION GATEWAY
echo ========================================================
echo   Starting local quantum decryption simulation node...
echo   Open your browser and navigate to:
echo.
echo   ---^> http://localhost:3000
echo.
echo   Press Ctrl+C to terminate node server stream.
echo ========================================================
echo.
python -m http.server 3000
pause
