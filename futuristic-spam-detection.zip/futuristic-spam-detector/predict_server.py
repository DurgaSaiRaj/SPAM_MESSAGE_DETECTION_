from __future__ import annotations  # Allows type hinting features from newer Python versions to work in this script.

import json  # Imports the JSON module to handle JSON conversion and serialization.
import math  # Imports math utilities for numeric validation checks like finite and range checks.
from pathlib import Path  # Imports Path for safe file and directory path handling.

import joblib  # Imports joblib to load the trained machine learning model from disk.
from flask import Flask, jsonify, request  # Imports Flask app class and request/response helpers for the API.
from flask_cors import CORS  # Imports CORS support so the API can accept requests from browser frontends.

BASE_DIR = Path(__file__).resolve().parent  # Sets the directory of this script as the base folder for model file access.
MODEL_PATH = BASE_DIR / "models" / "spam_model.joblib"  # Builds the full file path to the saved spam detection model.

app = Flask(__name__)  # Creates the Flask application instance for serving HTTP routes.
CORS(app)  

try:  # Attempts to load the trained model if it exists at the expected path.
    model = joblib.load(MODEL_PATH)  
except FileNotFoundError: 
    model = None  


@app.get("/health")  # Defines a GET endpoint that checks whether the API and model are ready.
def health() -> tuple[dict, int]: 
    return jsonify({"status": "ok", "model_loaded": model is not None}), 200  


@app.post("/predict")  # Defines a POST endpoint that accepts message text and predicts spam or ham.
def predict() -> tuple[dict, int]:
    payload = request.get_json(silent=True)  # Reads the incoming JSON body without raising an error on invalid input.
    if not isinstance(payload, dict): 
        return jsonify({"error": "Expected a JSON object containing text"}), 400  # Returns a 400 error for missing or malformed JSON.

    text = str(payload.get("text", "") or "").strip()  # Extracts text from the payload and converts it to a clean string.
    if not text:  
        return jsonify({"error": "Message text must not be empty"}), 400 

    if model is None:  # Checks whether the model file was successfully loaded before attempting predictions.
        return jsonify({"error": f"Trained model not found at {MODEL_PATH}"}), 503  # Returns HTTP 503 if the model is missing.

    threshold_value = payload.get("threshold", 0.35)  # Retrieves the optional spam threshold from the payload, defaulting to 0.35.
    if isinstance(threshold_value, bool):  # Rejects boolean values because they are not valid numeric thresholds.
        return jsonify({"error": "Threshold must be a number between 0.05 and 0.95"}), 400  # Returns a 400 error for invalid threshold type.
    try:  # Attempts to convert the threshold input to a numeric float.
        threshold = float(threshold_value) 
    except (TypeError, ValueError): 
        return jsonify({"error": "Threshold must be a number between 0.05 and 0.95"}), 400  
    if not math.isfinite(threshold) or not 0.05 <= threshold <= 0.95: 
        return jsonify({"error": "Threshold must be a number between 0.05 and 0.95"}), 400 

    probabilities = model.predict_proba([text])[0]  # Gets the model's probability outputs for the given message text.
    spam_probability = float(probabilities[1]) if len(probabilities) > 1 else 0.0  # Extracts the spam score from the second class probability when available.
    is_spam = spam_probability >= threshold  # Decides if the message should be labeled as spam based on the threshold.

    response = {  # Creates a dictionary containing the prediction result and metadata.
        "is_spam": is_spam,  
        "score": spam_probability,  
        "label": "spam" if is_spam else "ham",  # Labels the result as "spam" or "ham" based on the decision.
        "confidence": spam_probability if is_spam else 1.0 - spam_probability,  # Calculates the confidence as the spam score for spam or inverse for ham.
        "threshold": threshold,  
    }
    return jsonify(response), 200  # Sends the prediction JSON response back to the client with HTTP 200.


if __name__ == "__main__": 
    app.run(host="127.0.0.1", port=5001, debug=False) 